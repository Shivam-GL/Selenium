package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment_5 {

	public static void main(String[] args) {
		{
			System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
					
					WebDriver dr= new ChromeDriver();
					dr.get("http://examples.codecharge.com/Store/Default.php");
					
					WebElement we=dr.findElement(By.name("category_id"));
					Select se=new Select(we);
					se.selectByVisibleText("Databases");
					dr.findElement(By.name("DoSearch")).click();
					dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
					 we=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]"));
					String price=we.getText();
					
					price=price.substring(8);
					float price1=Float.parseFloat(price);
					float total1=price1*2;
				
					
					String S=dr.findElement(By.tagName("h1")).getText();
					String Expected_Text="Web Database Development";
					if(S.equals(Expected_Text)) {
						System.out.println("Pass");
					}
					
					dr.findElement(By.xpath("//input[@name=\"quantity\"]")).clear();
					dr.findElement(By.xpath("//input[@name=\"quantity\"]")).sendKeys("2");
					
					dr.findElement(By.name("Insert1")).click();
					String total=dr.findElement(By.tagName("p")).getText();
					total=total.substring(8);
					float total_1=Float.parseFloat(total);
					if(total_1==total1) {
						System.out.println("Pass");
					}
					
					
				
					dr.close();
				}
	}

}
