package sel_test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Assignment_4 {
	String userId;
	String passwd;
	String Expected_value;
	
	public static Assignment_4 read(int i) {
		Assignment_4 obj=new Assignment_4();
		try {
			File f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\5.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(i);
			XSSFCell cell=row.getCell(0);
			obj.userId=cell.getStringCellValue();
			cell=row.getCell(1);
			obj.passwd=cell.getStringCellValue();
			cell=row.getCell(2);
			obj.Expected_value=cell.getStringCellValue();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return obj;
		
	}
	public static void write_excel(int i,String a, String res){
		File f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\5.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow row=sh.getRow(i);
		XSSFCell cell=row.createCell(3);
		FileOutputStream fos = new FileOutputStream(f);
		cell.setCellValue(a);
		cell=row.createCell(4);
		cell.setCellValue(res);
		wb.write(fos);
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	public static void selwork(int i,Assignment_4 assign) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr= new ChromeDriver();
		String result = null;
		String a = null;
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys(assign.userId);
		dr.findElement(By.id("Password")).sendKeys(assign.passwd);
		dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
		
		boolean y=false;
		boolean z=false;
		try {
		y=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).isDisplayed();
		}
		catch(Exception e) {
			System.out.println("not displayed");
		}
		if(y==true) {
			
				 	String h=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
					String error_msg=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
					 a=h+error_msg;
					System.out.println(error_msg);
					if(a.equals(assign.Expected_value)) {
					result="Pass";
					}
					else {
					result="Fail";
					}
						
		}
		
		else {
				try {
				
				z=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
			}
			catch(Exception e) {
				System.out.println("handle please");
				}
			
				if(z==true) {
					a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
					System.out.println(a);
					if(a.equals(assign.Expected_value)) {
						result="Pass";
					}
					else {
						result="Fail";
					}
				}
				else {
		a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
			 
		if(a.equals(assign.Expected_value)) {
			result="Pass";
		}
		else {
			result="Fail";
		}
		}
		}
		
		write_excel(i,a,result);
		dr.close();
	}
	public static void main(String[] args) {
		
			Assignment_4 assign;
			for(int i=1;i<=4;i++) {
				assign=read(i);
				selwork(i,assign);
			}
}
}
