package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment_6 {

	public static void main(String[] args) {
		int[] qty=new int[3];
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
			Searchdb(dr);
			Additem(dr,qty);
			Evaluate(dr,qty);
			dr.close();

	}
	
	public static void Searchdb(WebDriver dr)
	{
		WebElement we=dr.findElement(By.name("category_id"));
		Select se=new Select(we);
		se.selectByVisibleText("Databases");
		dr.findElement(By.name("DoSearch")).click();
	}
	
	public static void Additem(WebDriver dr,int[] qty)
	{
			for(int i=1,j=2,k=0;i<=5;i=i+2) {
			dr.findElement(By.xpath("//table[@class=\"Grid\"]//tr["+i+"]//td[2]//a")).click();
			
			dr.findElement(By.xpath("//input[@name=\"quantity\"]")).clear();
			dr.findElement(By.xpath("//input[@name=\"quantity\"]")).sendKeys(""+j);
			qty[k++]=j;
			dr.findElement(By.name("Insert1")).click();
			dr.findElement(By.xpath("//a[@href=\"Default.php\"]")).click();
			j++;
			Searchdb(dr);
			}
		}
	public static void Evaluate(WebDriver dr,int[] qty) {
		dr.findElement(By.xpath("//a[@href=\"ShoppingCart.php\"]")).click();
		String price;
		String total;
		float Gsum=0;
		String sum;
		for(int i=2,k=0;i<=4;i++) {
			price=dr.findElement(By.xpath("//table[@class=\"Grid\"]//tr["+i+"]//td[2]")).getText();
			price=price.substring(1);
			float price1=Float.parseFloat(price);
			float total_eva=price1*qty[k++];
			total=dr.findElement(By.xpath("//table[@class=\"Grid\"]//tr["+i+"]//td[4]")).getText();
			total=total.substring(1);
			float total1=Float.parseFloat(total);
			Gsum+=total1;
			if(total1==total_eva) {
				System.out.println("Correct total");
			}	
		}
		
			sum=dr.findElement(By.tagName("p")).getText();
			sum=sum.substring(8);
			float sum1=Float.parseFloat(sum);
			if(sum1==Gsum) {
				System.out.println("Grand total is also correct");
			}
	}
}
