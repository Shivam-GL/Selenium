package new1;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base_classes.login_2;

public class data_provider extends login_2{
  @Test(dataProvider="logindataprovider")
  public void  login_now(String eid,String pwd,String er) {
	  launch_chrome();
	  this.userId=eid;
	  this.passwd=pwd;
	  this.ev=er;
	  this.av=login();
	  Assert.assertEquals(av, ev);
  }
  
  @DataProvider(name="logindataprovider")
  public String[][] get_testdata(){
	  String[][] logintestdata= {
			  							{"qsarty@gmail.com","qwertyu","qsarty@gmail.com"},
			  							{"aaaaaa","aaaaaaa","Please enter a valid email address."}
	  							};
	  return logintestdata;
  }
  
}
