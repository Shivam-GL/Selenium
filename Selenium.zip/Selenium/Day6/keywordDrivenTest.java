package new1;

import java.util.ArrayList;


public class keywordDrivenTest extends excel_io{

	public static void main(String[] args) {
		ArrayList<WebElements> A1=read_excel();
		
		for(WebElements w1:A1) {
			switch(w1.Keyword){
			case "launch_chrome": launch_chrome(w1.xPath);
			break;
			case "enterText": enterText(w1.xPath,w1.testData);
			break;
			case "Click":Click(w1.xPath);
			break;
			case "verify":verify(w1.xPath,w1.testData);
			break;
			}
		}
		
			write_excel(A1.get(4));
		
	}
	}


