package new1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElements {

	public static WebDriver dr;
	public String Keyword;
	public String xPath;
	public String testData;
	public static String testResult;

	public static void launch_chrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	
	public static void enterText(String xPath, String data) {
		dr.findElement(By.xpath(xPath)).sendKeys(data);
	}
	
	public static void Click(String xPath) {
		dr.findElement(By.xpath(xPath)).click();
	}
	
	public static void verify(String xPath,String testData) {
		String av=dr.findElement(By.xpath(xPath)).getText();
		if(av.equals(testData)) {
			testResult="pass";
		}
		else {
			testResult="fail";
		}
	}
	
}
