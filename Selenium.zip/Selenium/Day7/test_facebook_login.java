package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class test_facebook_login {
	WebDriver dr;
	fb_login_page loginpage;
	fb_home_page homepage;
	@BeforeClass
	public void launcBrowser() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get("http://www.facebook.com");
		
	}
  @Test(priority=0)
  public void test_login_page() {
	  loginpage=new fb_login_page(dr);
	  String login_page_title=loginpage.get_title();
	  System.out.println("Title: "+login_page_title);
	  Assert.assertTrue(login_page_title.contains("Facebook"));
  }
  @Test(priority=2)
  public void test_home_page(){
	  loginpage.do_login("girishindia95@gmail.com", "mynewp@55");
	  homepage=new fb_home_page(dr);
	  String actual_pn=homepage.get_profilename();
	  System.out.println("Actual Profile name: "+actual_pn);
	  Assert.assertTrue(actual_pn.contains("Girish"));
	  
  }
}
