package day5;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Asserts {
	Logger log;
  @Test
  public void test1 (){
	  String er="noida",ar="noida";
	  System.out.println("in test");
	  Assert.assertEquals(er, ar);
	  System.out.println("After assert");
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("test1 executed");
  }
  
  @Test
  public void test2 (){
	  String er="noida",ar="noida";
	  System.out.println("in test");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(er, ar);
	  System.out.println("After assert");
	  sa.assertAll();
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("test2 executed");
  }
  
}
