package day5;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base_classes.login_2;


public class new3 extends login_2 {
  @BeforeMethod
  public void Bm() {
	  launch_chrome();
  }
  @AfterMethod
  public void Am() {
	  dr.close();
  }
  
  
	  @Test
	  public void TC1() {
		  this.userId="qsarty@gmail.com";
		  this.passwd="qwertyu";
		  this.ev="qsarty@gmail.com";
		  this.av=login();
		  Assert.assertEquals(av, ev);
	  }
	  
	 @Test
	 public void TC2() {
		  this.userId="aaaaaggg@gmail.com";
		  this.passwd="aaaaaagaga";
		  this.ev="Login was unsuccessful. Please correct the errors and try again.No customer account found";
		  this.av=login();
		  Assert.assertEquals(av, ev);
	 }
	 @Test
	 public void TC3() {
		  this.userId="aaaaa";
		  this.passwd="aaaaaa";
		  this.ev="Please enter a valid email address.";
		  this.av=login();
		  Assert.assertEquals(av, ev);
	 }
	 
}
  

