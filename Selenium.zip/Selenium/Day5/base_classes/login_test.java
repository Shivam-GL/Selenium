package base_classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_test {
	public String userId, passwd,ev,av,result;
	
	public String login() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr= new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys(userId);
		dr.findElement(By.id("Password")).sendKeys(passwd);
		dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
		av=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		return av;
	}

}
