package base_classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_2 {
	
public static WebDriver dr;
public String userId, passwd,ev,av,result;

public static void launch_chrome() {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
	}

public String login() {
	dr.findElement(By.className("ico-login")).click();
	dr.findElement(By.id("Email")).sendKeys(userId);
	dr.findElement(By.id("Password")).sendKeys(passwd);
	dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
	boolean y=false;
	boolean z=false;
	try {
	y=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).isDisplayed();
	}
	catch(Exception e) {
		System.out.println("not displayed");
	}
	if(y==true) {
		
			 	String h=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
				String error_msg=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
				 av = h + error_msg;
				System.out.println(error_msg);
	}
	
	else {
			try {
			
			z=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
		}
		catch(Exception e) {
			System.out.println("handle please");
			}
		
			if(z==true) {
				av=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
			}
			else
				av=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	
	
}
	return av;

}
}
