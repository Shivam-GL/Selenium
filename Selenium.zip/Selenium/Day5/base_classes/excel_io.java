package base_classes;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import new1.WebElements;

public class excel_io {

	public static String[][] read_excel(){
		String[][] testcases=new String[4][4];
		
		for(int i=1, j=0;i<=4;i++) {
			
			
			try {
				
				File f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\5.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow row=sh.getRow(i);
				XSSFCell cell=row.getCell(0);
				testcases[j][0]=cell.getStringCellValue();
				cell=row.getCell(1);
				testcases[j][1]=cell.getStringCellValue();
				cell=row.getCell(2);
				testcases[j][2]=cell.getStringCellValue();
				j++;
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			}
		return testcases;
	}
}
