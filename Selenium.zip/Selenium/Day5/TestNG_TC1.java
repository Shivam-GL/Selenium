package new2;

import org.testng.annotations.Test;

public class TestNG_TC1 {
  @Test
  public void tc1() {
	  System.out.println("in tc1");
	  tc2();
  }
  public void tc2() {
	  System.out.println("in tc2");
  }
  @Test
  public void tc3() {
	  System.out.println("in tc3");
  }
}
