package new2;

import org.testng.Assert;
import org.testng.annotations.Test;

import base_classes.login_test;

public class Test3 extends login_test {
  @Test
  public void TC1() {
	  this.userId="qsarty@gmail.com";
	  this.passwd="qwertyu";
	  this.ev="qsarty@gmail.com";
	  this.av=login();
	  Assert.assertEquals(av, ev);
  }
  
 @Test
 public void TC2() {
	  this.userId="qsarty@gmail.com";
	  this.passwd="qwertyu";
	  this.ev="qsy@gmail.com";
	  this.av=login();
	  Assert.assertEquals(av, ev);
 }
}
