package new2;


import org.testng.annotations.Test;

import day5.alerts;

public class TC2 extends alerts{
  @Test
  public void tc_1() {
	 launch_chrome();
	 del_customer();
	 dr.close();
  }
  
  @Test
  public void tc_2() 
	{
		 launch_chrome();
		 rej_del_cust();
		 dr.close();
	}
  
}