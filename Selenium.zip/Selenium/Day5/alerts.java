package day5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class alerts
{
	public static WebDriver dr;
	static String url="http://demo.guru99.com/test/delete_customer.php";
	
	public static void launch_chrome() {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	
	public static void del_customer() {
		dr.findElement(By.name("cusid")).sendKeys("asbbf");
		dr.findElement(By.name("submit")).click();
		dr.switchTo().alert().accept();
		dr.switchTo().alert().accept();
		
	}
	public static void rej_del_cust() {
		dr.findElement(By.name("cusid")).sendKeys("asbbf");
		dr.findElement(By.name("submit")).click();
		dr.switchTo().alert().dismiss();
		
	}
	public static void main(String[] args) {

		launch_chrome();
		del_customer();
		rej_del_cust();
		dr.close();
		
		
	}

}
