package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_3 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("qsarty@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("qwertyu");
		dr.findElement(By.xpath("//input[@value=\"Log in\"]")).click();
		String a=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		if(a.equals("qsarty@gmail.com")) {
			System.out.println("Pass");
		}
		dr.close();
		

	}

}
