package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1 {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String s=dr.getTitle();
		String Expected_title="Demo Web Shop";
		if(s.equals(Expected_title)) {
			System.out.println("Pass");
		}
		else {
			System.out.println("fail");
		}
		WebElement we;
		we=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
		we.click();
		String s2=dr.getTitle();
		String Expected_title2="Demo Web Shop. Register";
		if(s2.equals(Expected_title2)) {
			System.out.println("Pass");
		}
		else {
			System.out.println("fail");
		}
		dr.findElement(By.id("gender-male")).click();
		dr.findElement(By.id("FirstName")).sendKeys("XXVVY");
		dr.findElement(By.id("LastName")).sendKeys("XXVVY");
		dr.findElement(By.id("Email")).sendKeys("wsarty@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("wwertyu");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("wwertyu");
		dr.findElement(By.id("register-button")).click();
		dr.findElement(By.className("ico-logout")).click();
		dr.close();
		
		
	}

}
