package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class cpy_paste {

	public static void main(String[] args) {
	
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		WebElement we2=dr.findElement(By.xpath("//input[@name='firstname']"));
		WebElement we3=dr.findElement(By.xpath("//input[@name='lastname']"));
		Actions act=new Actions(dr);
		Action many_actions=act
							.moveToElement(we2)
							.click(we2)
							.sendKeys("Java")
							.keyDown(we2,Keys.CONTROL)
							.sendKeys("A")
							.sendKeys("C")
							.keyUp(we2,Keys.CONTROL)
							.build();
		
		many_actions.perform();
		
		Actions act1=new Actions(dr);
		Action set= act1
					.moveToElement(we3)
					.click(we3)
					.keyDown(we3, Keys.CONTROL)
					.sendKeys(we3,"V")
					.keyUp(we3, Keys.CONTROL)
					.build();
		
		set.perform();
		
	}

}
