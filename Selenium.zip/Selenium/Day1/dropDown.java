package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class dropDown {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("https://www.facebook.com");
		WebElement we= dr.findElement(By.id("day"));
		Select sel1=new Select(we);
		sel1.selectByVisibleText("10");
		System.setProperty("webdriver.ie.driver","D:\\Drivers\\IEDriverServer.exe");
		WebDriver dr1=new InternetExplorerDriver();
		dr1.get("https://www.facebook.com");
		System.setProperty("webdriver.gecko.driver","D:\\Drivers\\geckodriver.exe" );
		WebDriver dr3=new FirefoxDriver();
		dr3.get("https://www.facebook.com");

	}

}
