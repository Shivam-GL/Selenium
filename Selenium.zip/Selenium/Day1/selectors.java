package sel_test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class selectors {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		
		WebDriver dr= new ChromeDriver();
		dr.get("https://www.facebook.com");
		WebElement we=dr.findElement(By.cssSelector("input[type='submit']"));
		we.click();

	}

}
